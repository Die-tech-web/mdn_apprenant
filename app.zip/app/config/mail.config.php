<?php

return [
    'smtp' => [
        'host' => 'smtp.gmail.com',        // Serveur SMTP de Gmail
        'port' => 587,                     // Port SMTP (587 pour TLS)
        'username' => 'dieniang32@gmail.com', // Votre adresse Gmail
        'password' => 'lror qkol jigj qnig', // Mot de passe d'application Gmail
        'encryption' => 'tls',             // Encryption (tls recommandé)
        'from_email' => 'dieniang32@gmail.com',
        'from_name' => 'Orange Digital center', // Nom de l'expéditeur
    ]
];